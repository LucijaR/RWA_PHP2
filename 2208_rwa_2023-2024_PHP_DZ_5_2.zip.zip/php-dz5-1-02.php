<!DOCTYPE html>
<html lang="hr">
<head>

 <meta charset="UTF-8" />
 <title>Varijable</title>
 
</head>

<body>
 <?php
/*2.	Napisati php skriptu s pripadajućim PHP funkcijom koja ima dva ulazna argumenta (brojčane vrijednosti), Funkcija zatim ispisuje aritmetičku  sredinu između ta dva broja. 
Izvršiti nekoliko poziva funkcije s proizvoljnim vrijednostima!*/
print("Zadatak 2:</br>");

function aritmeticka($prvi, $drugi) 
{
   $sredina = ($prvi + $drugi)/2;
   print("Aritmeticka sredina je: $sredina</br>");
}

aritmeticka(89, 11);
aritmeticka(13, 33);
aritmeticka(9, 1249);

?>
 
</body>
</html>