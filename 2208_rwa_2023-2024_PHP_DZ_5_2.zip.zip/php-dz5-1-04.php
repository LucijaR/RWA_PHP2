<!DOCTYPE html>
<html lang="hr">
<head>

 <meta charset="UTF-8" />
 <title>Varijable</title>
 
</head>

<body>
 <?php
/*.4.	Zadatak: Napisati PHP/HTML program koji generira sljedeći ispis unutar preglednika putem PHP koda. PHP kod računa faktorijel za svaki broj do broja koji unesemo kao argument funkcije.
 Program mora imati sljedeću strukturu – prvo definirati funkciju za faktorijel koja radi ispis kao u prozoru ispod (Izvršiti nekoliko poziva funkcije s proizvoljnim vrijednostima!*/
print("Zadatak 4:</br>");

function faktorijel($n) 
{
    if ($n == 0 || $n == 1)
    {
        return 1;
    } 
    else 
    {
        return $n * faktorijel($n - 1);
    }
}

$broj=6;
for ($i = 1; $i <=$broj; $i++) 
{
    $rez = faktorijel($i);
    print("$i! = $rez<br>");
}

?>
 
</body>
</html>