<!DOCTYPE html>
<html lang="hr">
<head>

 <meta charset="UTF-8" />
 <title>Varijable</title>
 
</head>

<body>
 <?php
/*1.	Napišite funkciju koja će ispitati da li je broj prost. Prosti brojevi su djeljivi isključivo sa samim sobom ili s 1. Zatim, ispišite sve proste brojeve manje od 100!*/
print("Zadatak 1:</br>");
function provjera($x)
{
    $brojac=0;
    for ($i=2; $i<$x; $i++) 
	{
        if ($x % $i ==0) 
		{
            $brojac++;
        }
    }
    return $brojac;
}

print("Prosti brojevi manji od 100:</br>");
for ($i=2; $i<100; $i++) 
{
    if (provjera($i) == 0) 
	{
        print($i.'</br>');
    }
}

?>
 
</body>
</html>