<!DOCTYPE html>
<html lang="hr">
<head>

 <meta charset="UTF-8" />
 <title>Varijable</title>
 
</head>

<body>
 <?php
/*5.	Napišite PHP funkciju unutar skripte za promjenu svih vrijednosti ulaznog polja na način da sve članove polja promijeni u mala ili velika slova. Funkcija ima dva ulazna argumenta, 
ulazno polje i željeni oblik ispisa unesen kao niz (UPPER ILI LOWER). Na kraju skripte uraditi više poziva funkcije…
Primjer input polja :
$boje = array('B' => 'Blue', 'G' => 'Green', 'r' => 'Red');
Očekivani izlaz :
Vrijednosti u  lowercase.
Array ( [B] => blue [G] => green [r] => red ) 
Vrijednosti u  uppercase.
Array ( [B] => BLUE [G] => GREEN [r] => RED )*/
print("Zadatak 5:</br>");

function promijeni($ulaznoPolje, $oblikIspisa) 
{
    $promijenjenoPolje = array();

    foreach ($ulaznoPolje as $kljuc => $vrijednost) 
	{
        if ($oblikIspisa == 'UPPER') 
		{
            $promijenjenoPolje[$kljuc] = strtoupper($vrijednost);
        } 
		elseif ($oblikIspisa == 'LOWER') 
		{
            $promijenjenoPolje[$kljuc] = strtolower($vrijednost);
        }
    }

    return $promijenjenoPolje;
}

$boje = array('B' => 'Blue', 'G' => 'Green', 'r' => 'Red');

print("Mala slova: <br>");
print_r(promijeni($boje, 'LOWER'));

print("</br>Velika slova: ");
print_r(promijeni($boje, 'UPPER'));

?>
 
</body>
</html>