<!DOCTYPE html>
<html lang="hr">
<head>

 <meta charset="UTF-8" />
 <title>Varijable</title>
 
</head>

<body>
 <?php
/*6.	Napišite PHP skriptu s funkcijom za izračun i prikaz prosječne temperature, deset  najnižih i desetnajviših temperatura. Funkcija ima samo jedan ulazni argument, 
niz temparature (niz/string , vrijednosti odvojene zarezom) – primjer niza temperature:
$temparature = "78, 60, 62, 68, 71, 68, 73, 85, 66, 64, 76, 63, 81, 76, 73, 68, 72, 73, 75, 65, 74, 63, 67, 65, 64, 68, 73, 75, 79, 73";*/
print("Zadatak 6:</br>");

$temperature = "78, 60, 62, 68, 71, 68, 73, 85, 66, 64, 76, 63, 81, 76, 73, 68, 72, 73, 75, 65, 74, 63, 67, 65, 64, 68, 73, 75, 79, 73";

function pronadji($temperature) 
{
    $temperatureArray =explode(', ', $temperature);
    $prosjek = array_sum($temperatureArray) / count($temperatureArray);
    sort($temperatureArray);

    $najnize = array_slice($temperatureArray, 0, 10);
    $najvise = array_slice($temperatureArray, -10);

   print("Prosjek: $prosjek<br>");
   print("Deset najnižih: " . implode(', ', $najnize) . "<br>");
   print("Deset najviših: " . implode(', ', $najvise) . "<br>");
}
pronadji($temperature);
?>
 
</body>
</html>