<!DOCTYPE html>
<html lang="hr">
<head>

 <meta charset="UTF-8" />
 <title>Varijable</title>
 
</head>

<body>
 <?php
/*3.	Napisati php skriptu s pripadajućom PHP funkcijom koja ima jedan ulazni argumenta (niz brojčanih vrijednosti kao string, odvojenih zarezom), Funkcija zatim ispisuje aritmetičku  
i geometrijsku sredinu između tih brojeva Izvršiti nekoliko poziva funkcije s proizvoljnim nizom vrijednostima!*/
print("Zadatak 3:</br>");

function funkcija($brojevi)
 {
    $niz = explode(',', $brojevi);
    $aritmeticka = array_sum($niz)/count($niz);

    $geometrijska= 1;
    foreach ($niz as $broj) 
	{
        $geometrijska =$geometrijska * $broj;
    }
    $geometrijska= pow($geometrijska, 1/ count($niz));

    print("Aritmetička sredina je: $aritmeticka</br>");
    print("Geometrijska sredina je: $geometrijska</br>");
}
funkcija("7, 34, 4, 11");
funkcija("88, 4, 13, 0, 1");
funkcija("17, 3, 19");
funkcija("1, 2");

?>
 
</body>
</html>